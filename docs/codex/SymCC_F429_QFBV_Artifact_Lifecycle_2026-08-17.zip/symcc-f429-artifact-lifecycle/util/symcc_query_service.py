#!/usr/bin/env python3
"""Ingest SymCC query spools and solve them with independent workers."""

from __future__ import annotations

import argparse
import errno
import fcntl
import json
import os
import shlex
import shutil
import signal
import socket
import stat
import sys
import threading
import time
import uuid
from contextlib import ExitStack
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from query_store import (
    PersistentSubprocessSolver,
    PortfolioSolver,
    QueryAdmissionError,
    QueryStore,
    SubprocessSolver,
    solve_one,
)
from qf_bv_backend import (
    PersistentSmtLibQfbvSolver,
    SmtLibQfbvSolver,
    normalize_qfbv_capabilities,
)
from cross_worker_context import CrossWorkerContextStore
from qfbv_proof_receipt import (
    MAX_PROOF_BYTES,
    ProofVerificationError,
    QfbvProofStore,
    QfbvProofVerifier,
    normalize_qfbv_proof_config,
)
from qfbv_lemma_exchange import (
    MAX_RECORD_BYTES,
    QfbvLemmaExchange,
    QfbvLemmaStore,
)
from qfbv_artifact_lifecycle import (
    ArtifactCollection,
    ArtifactJobLease,
    ArtifactLeaseHeartbeat,
    ArtifactLifecycleRegistry,
)


def _environment_integer(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        return int(raw, 10)
    except ValueError as error:
        raise ValueError(f"{name} must be an integer") from error


def _environment_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        return float(raw)
    except ValueError as error:
        raise ValueError(f"{name} must be a number") from error


def _move(source: Path, destination_dir: Path) -> None:
    destination_dir.mkdir(parents=True, exist_ok=True)
    destination = destination_dir / source.name
    if destination.exists():
        destination = destination_dir / (
            f"{source.stem}-{time.time_ns()}{source.suffix}"
        )
    os.replace(source, destination)


def _try_spool_ingest_lock(spool: Path) -> int | None:
    no_follow = getattr(os, "O_NOFOLLOW", None)
    if no_follow is None:
        raise OSError(
            errno.EOPNOTSUPP,
            "O_NOFOLLOW is required for query spool locking",
        )
    lock_path = spool / ".ingest.lock"
    flags = (
        os.O_RDWR
        | os.O_CREAT
        | no_follow
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NONBLOCK", 0)
    )
    descriptor = os.open(lock_path, flags, 0o600)
    try:
        metadata = os.fstat(descriptor)
        path_metadata = os.stat(lock_path, follow_symlinks=False)
        if (
            not stat.S_ISREG(metadata.st_mode)
            or not stat.S_ISREG(path_metadata.st_mode)
            or (metadata.st_dev, metadata.st_ino)
            != (path_metadata.st_dev, path_metadata.st_ino)
        ):
            raise OSError(
                getattr(errno, "ESTALE", errno.EIO),
                "query spool lock identity is not stable",
                lock_path,
            )
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            if error.errno in {errno.EACCES, errno.EAGAIN}:
                os.close(descriptor)
                return None
            raise
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def ingest_spool(store: QueryStore, spool: Path) -> tuple[int, int]:
    incoming = spool / "incoming"
    accepted = spool / "accepted"
    rejected = spool / "rejected"
    incoming.mkdir(parents=True, exist_ok=True)
    lock_descriptor = _try_spool_ingest_lock(spool)
    if lock_descriptor is None:
        return 0, 0
    imported = 0
    failed = 0
    try:
        for path in sorted(incoming.glob("*.json")):
            try:
                store.ingest_file(path)
            except QueryAdmissionError as exc:
                error = rejected / f"{path.name}.error"
                error.parent.mkdir(parents=True, exist_ok=True)
                error.write_text(
                    f"ValueError: {exc}\n",
                    encoding="utf-8",
                )
                _move(path, rejected)
                failed += 1
                continue

            # Publication failure is retryable, not an invalid Query IR.
            _move(path, accepted)
            imported += 1
        return imported, failed
    finally:
        os.close(lock_descriptor)


def _default_solver() -> list[str]:
    configured = os.environ.get("SYMCC_QUERY_SOLVER", "")
    if configured:
        return shlex.split(configured)
    discovered = shutil.which("symcc-query-solver")
    if discovered:
        return [discovered]
    root = Path(__file__).resolve().parents[1]
    candidates = sorted(
        root.glob(
            "build/SymCCRuntime-prefix/src/SymCCRuntime-build/"
            "src/backends/qsym/symcc-query-solver"
        )
    )
    if candidates:
        return [str(candidates[-1])]
    raise RuntimeError("symcc-query-solver was not found; set SYMCC_QUERY_SOLVER")


def _load_portfolio(raw: str) -> list[dict[str, object]]:
    if not raw:
        return []
    try:
        if os.path.isfile(raw):
            with open(raw, encoding="utf-8") as stream:
                data = json.load(stream)
        else:
            data = json.loads(raw)
    except (OSError, ValueError, TypeError) as exc:
        raise RuntimeError("invalid solver portfolio JSON") from exc
    if isinstance(data, dict):
        data = data.get("solvers", ())
    if not isinstance(data, list):
        raise RuntimeError("solver portfolio must be a list")
    solvers: list[dict[str, object]] = []
    for index, raw_solver in enumerate(data[:32]):
        if not isinstance(raw_solver, dict):
            continue
        command = raw_solver.get("command")
        if isinstance(command, str):
            command_value = shlex.split(command)
        elif isinstance(command, list) and all(
            isinstance(item, str) for item in command
        ):
            command_value = list(command)
        else:
            continue
        if not command_value:
            continue
        name = str(raw_solver.get("name", f"solver{index}"))[:128]
        kind = str(raw_solver.get("kind", "symcc-json"))
        if kind not in {"symcc-json", "smtlib-qfbv"}:
            raise RuntimeError(f"unsupported solver portfolio kind {kind!r}")
        solver = {
            "name": name,
            "kind": kind,
            "command": command_value,
            "persistent": bool(raw_solver.get("persistent", kind == "symcc-json")),
        }
        if kind == "smtlib-qfbv":
            try:
                solver["capabilities"] = normalize_qfbv_capabilities(
                    raw_solver.get("capabilities")
                )
            except ValueError as error:
                raise RuntimeError(
                    f"invalid capabilities for solver {name!r}"
                ) from error
            if solver["persistent"] and not solver["capabilities"]["incremental"]:
                raise RuntimeError(
                    f"persistent solver {name!r} must advertise incremental"
                )
            try:
                prefix_cache = int(raw_solver.get("prefix_cache", 4))
            except (TypeError, ValueError, OverflowError) as error:
                raise RuntimeError(
                    f"invalid prefix cache for solver {name!r}"
                ) from error
            if prefix_cache < 1 or prefix_cache > 64:
                raise RuntimeError(
                    f"prefix cache for solver {name!r} must be in [1, 64]"
                )
            solver["prefix_cache"] = prefix_cache
            proof_raw = raw_solver.get("unsat_proof")
            if proof_raw is not None:
                if not isinstance(proof_raw, dict):
                    raise RuntimeError(
                        f"invalid UNSAT proof configuration for solver {name!r}"
                    )
                try:
                    solver["unsat_proof"] = normalize_qfbv_proof_config(
                        proof_raw
                    )
                except ProofVerificationError as error:
                    raise RuntimeError(
                        f"invalid UNSAT proof configuration for solver {name!r}"
                    ) from error
            lemma_raw = raw_solver.get("learned_lemmas")
            if lemma_raw is not None:
                if not isinstance(lemma_raw, dict):
                    raise RuntimeError(
                        f"invalid learned lemma configuration for solver {name!r}"
                    )
                if not solver["persistent"] or "unsat_proof" not in solver:
                    raise RuntimeError(
                        "learned lemma exchange requires a persistent QF_BV "
                        "solver with unsat_proof"
                    )
                literal_type = str(lemma_raw.get("type", "preprocess"))
                if literal_type not in {
                    "preprocess",
                    "input",
                    "solvable",
                    "internal",
                }:
                    raise RuntimeError(
                        f"invalid learned literal type for solver {name!r}"
                    )
                try:
                    maximum = int(lemma_raw.get("max_per_query", 8))
                    timeout = int(lemma_raw.get("timeout_ms", 30_000))
                except (TypeError, ValueError, OverflowError) as error:
                    raise RuntimeError(
                        f"invalid learned lemma bounds for solver {name!r}"
                    ) from error
                if not 1 <= maximum <= 64 or not 1 <= timeout <= 3_600_000:
                    raise RuntimeError(
                        f"learned lemma bounds for solver {name!r} are invalid"
                    )
                solver["learned_lemmas"] = {
                    "type": literal_type,
                    "max_per_query": maximum,
                    "timeout_ms": timeout,
                }
        elif raw_solver.get("unsat_proof") is not None:
            raise RuntimeError("UNSAT proof receipts require smtlib-qfbv kind")
        elif raw_solver.get("learned_lemmas") is not None:
            raise RuntimeError("learned lemma exchange requires smtlib-qfbv kind")
        solvers.append(solver)
    if not solvers:
        raise RuntimeError("solver portfolio does not contain valid solvers")
    return solvers


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--spool", type=Path)
    parser.add_argument("--solver", help="solver helper command")
    parser.add_argument(
        "--portfolio",
        help="JSON or path: {'solvers':[{'name':'z3','command':'...'}]}",
    )
    parser.add_argument(
        "--portfolio-parallelism",
        type=int,
        default=0,
        help="max concurrent solvers per portfolio query; 0 uses environment/auto",
    )
    parser.add_argument(
        "--portfolio-cancel-grace-ms",
        type=int,
        default=None,
        help=(
            "cancel remaining attempts this many ms after a SAT result; "
            "unset uses the environment and -1 disables cancellation"
        ),
    )
    parser.add_argument(
        "--qfbv-context-store",
        type=Path,
        help=(
            "shared content-addressed QF_BV prefix context directory; "
            "defaults to SYMCC_QFBV_CONTEXT_STORE"
        ),
    )
    parser.add_argument(
        "--qfbv-context-max-objects",
        type=int,
        default=None,
        help="maximum number of shared QF_BV context objects",
    )
    parser.add_argument(
        "--qfbv-context-max-active",
        type=int,
        default=None,
        help="cluster-wide active shared-context materialization quota",
    )
    parser.add_argument(
        "--qfbv-context-lease-seconds",
        type=float,
        default=None,
        help="fenced shared-context materialization lease duration",
    )
    parser.add_argument(
        "--qfbv-proof-store",
        type=Path,
        help=(
            "shared content-addressed QF_BV UNSAT proof directory; "
            "defaults to SYMCC_QFBV_PROOF_STORE or a store-local directory"
        ),
    )
    parser.add_argument(
        "--qfbv-proof-max-objects",
        type=int,
        default=None,
        help="maximum combined QF_BV proof and receipt objects",
    )
    parser.add_argument(
        "--qfbv-proof-max-bytes",
        type=int,
        default=None,
        help="maximum bytes in one raw CPC proof body",
    )
    parser.add_argument(
        "--qfbv-lemma-store",
        type=Path,
        help=(
            "shared content-addressed verified QF_BV lemma directory; "
            "defaults to SYMCC_QFBV_LEMMA_STORE or a store-local directory"
        ),
    )
    parser.add_argument(
        "--qfbv-lemma-max-records",
        type=int,
        default=None,
        help="maximum verified QF_BV lemma records",
    )
    parser.add_argument(
        "--qfbv-lemma-max-bytes",
        type=int,
        default=None,
        help="maximum total encoded bytes in the verified lemma store",
    )
    parser.add_argument(
        "--qfbv-artifact-lifecycle-store",
        type=Path,
        help=(
            "shared fenced job-root and dependency graph directory; "
            "defaults to SYMCC_QFBV_ARTIFACT_LIFECYCLE_STORE"
        ),
    )
    parser.add_argument(
        "--qfbv-artifact-max-jobs",
        type=int,
        default=None,
        help=(
            "maximum distinct fenced artifact job IDs retained by one "
            "lifecycle store"
        ),
    )
    parser.add_argument(
        "--qfbv-artifact-job-id",
        help="stable campaign/job identity for fenced artifact roots",
    )
    parser.add_argument(
        "--qfbv-artifact-job-lease-seconds",
        type=float,
        default=None,
        help="lifetime of one renewable artifact-root lease",
    )
    parser.add_argument(
        "--qfbv-artifact-gc-on-start",
        action="store_true",
        help="run one bounded artifact collection before solving",
    )
    parser.add_argument(
        "--qfbv-artifact-gc-only",
        action="store_true",
        help="run one bounded artifact collection and exit",
    )
    parser.add_argument(
        "--qfbv-artifact-gc-grace-seconds",
        type=float,
        default=None,
        help="retain artifacts accessed within this wall-clock grace period",
    )
    parser.add_argument(
        "--qfbv-artifact-gc-max-objects",
        type=int,
        default=None,
        help="hard object-deletion budget for one collection",
    )
    parser.add_argument(
        "--qfbv-artifact-gc-max-bytes",
        type=int,
        default=None,
        help="hard byte-deletion budget for one collection",
    )
    parser.add_argument(
        "--qfbv-artifact-gc-time-ms",
        type=int,
        default=None,
        help=(
            "selection/lock budget for one collection; an admitted atomic "
            "deletion is allowed to finish"
        ),
    )
    parser.add_argument(
        "--qfbv-artifact-gc-scan-max-objects",
        type=int,
        default=None,
        help="hard pre-GC cross-store index synchronization budget",
    )
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--poll", type=float, default=0.25)
    parser.add_argument("--lease-seconds", type=float, default=60.0)
    parser.add_argument("--max-attempts", type=int, default=3)
    parser.add_argument(
        "--traversal",
        choices=("dfs", "bfs", "priority", "structural"),
        default="structural",
        help="persistent query scheduling policy",
    )
    parser.add_argument(
        "--once",
        action="store_true",
        help="drain currently available work and exit",
    )
    parser.add_argument(
        "--schedule-constraints",
        type=Path,
        help="consume symcc-schedule-constraint-v1 JSONL for joint validation",
    )
    parser.add_argument(
        "--schedule-validation-out",
        type=Path,
        help="append symcc-joint-schedule-query-v1 validation JSONL",
    )
    parser.add_argument(
        "--schedule-validation-max-artifacts",
        type=int,
        default=4096,
        help="maximum schedule constraint rows scanned per validation pass",
    )
    parser.add_argument(
        "--schedule-validation-only",
        action="store_true",
        help="validate schedule artifacts against the query store and exit",
    )
    parser.add_argument(
        "--artifact-audit-only",
        action="store_true",
        help="report QueryStore SQLite-to-CAS reachability without deleting data",
    )
    parser.add_argument(
        "--artifact-audit-max-entries",
        type=int,
        default=100_000,
        help="maximum root and shard directory entries observed by an audit",
    )
    parser.add_argument(
        "--stats",
        action="store_true",
        help="print store statistics without running workers",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    store = QueryStore(args.store)
    portfolio_specs = _load_portfolio(
        args.portfolio or os.environ.get("SYMCC_QUERY_SOLVER_PORTFOLIO", "")
    )
    lifecycle_raw = (
        str(args.qfbv_artifact_lifecycle_store)
        if args.qfbv_artifact_lifecycle_store is not None
        else os.environ.get("SYMCC_QFBV_ARTIFACT_LIFECYCLE_STORE", "")
    )
    artifact_max_jobs = (
        args.qfbv_artifact_max_jobs
        if args.qfbv_artifact_max_jobs is not None
        else _environment_integer("SYMCC_QFBV_ARTIFACT_MAX_JOBS", 1_000_000)
    )
    if not 1 <= artifact_max_jobs <= 10_000_000:
        raise ValueError(
            "--qfbv-artifact-max-jobs must be in [1, 10000000]"
        )
    artifact_lifecycle = (
        ArtifactLifecycleRegistry(lifecycle_raw, max_jobs=artifact_max_jobs)
        if lifecycle_raw
        else None
    )
    artifact_job_lease_seconds = (
        args.qfbv_artifact_job_lease_seconds
        if args.qfbv_artifact_job_lease_seconds is not None
        else _environment_float("SYMCC_QFBV_ARTIFACT_JOB_LEASE_SECONDS", 60.0)
    )
    if not 0.1 <= artifact_job_lease_seconds <= 86_400.0:
        raise ValueError(
            "--qfbv-artifact-job-lease-seconds must be in [0.1, 86400]"
        )
    artifact_gc_grace_seconds = (
        args.qfbv_artifact_gc_grace_seconds
        if args.qfbv_artifact_gc_grace_seconds is not None
        else _environment_float(
            "SYMCC_QFBV_ARTIFACT_GC_GRACE_SECONDS", 86_400.0
        )
    )
    artifact_gc_max_objects = (
        args.qfbv_artifact_gc_max_objects
        if args.qfbv_artifact_gc_max_objects is not None
        else _environment_integer("SYMCC_QFBV_ARTIFACT_GC_MAX_OBJECTS", 1024)
    )
    artifact_gc_max_bytes = (
        args.qfbv_artifact_gc_max_bytes
        if args.qfbv_artifact_gc_max_bytes is not None
        else _environment_integer(
            "SYMCC_QFBV_ARTIFACT_GC_MAX_BYTES", 256 * 1024 * 1024
        )
    )
    artifact_gc_time_ms = (
        args.qfbv_artifact_gc_time_ms
        if args.qfbv_artifact_gc_time_ms is not None
        else _environment_integer("SYMCC_QFBV_ARTIFACT_GC_TIME_MS", 30_000)
    )
    artifact_gc_scan_max_objects = (
        args.qfbv_artifact_gc_scan_max_objects
        if args.qfbv_artifact_gc_scan_max_objects is not None
        else _environment_integer(
            "SYMCC_QFBV_ARTIFACT_GC_SCAN_MAX_OBJECTS", 100_000
        )
    )
    if not 0.0 <= artifact_gc_grace_seconds <= 365 * 86_400.0:
        raise ValueError(
            "--qfbv-artifact-gc-grace-seconds must be in [0, 31536000]"
        )
    if not 1 <= artifact_gc_max_objects <= 1_000_000:
        raise ValueError(
            "--qfbv-artifact-gc-max-objects must be in [1, 1000000]"
        )
    if not 1 <= artifact_gc_max_bytes <= 1 << 40:
        raise ValueError(
            f"--qfbv-artifact-gc-max-bytes must be in [1, {1 << 40}]"
        )
    if not 1 <= artifact_gc_time_ms <= 3_600_000:
        raise ValueError(
            "--qfbv-artifact-gc-time-ms must be in [1, 3600000]"
        )
    if not 1 <= artifact_gc_scan_max_objects <= 3_000_000:
        raise ValueError(
            "--qfbv-artifact-gc-scan-max-objects must be in [1, 3000000]"
        )
    if (args.qfbv_artifact_gc_on_start or args.qfbv_artifact_gc_only) and (
        artifact_lifecycle is None
    ):
        raise ValueError("artifact GC requires --qfbv-artifact-lifecycle-store")
    worker_mode = not (
        args.schedule_validation_only
        or args.artifact_audit_only
        or args.stats
        or args.qfbv_artifact_gc_only
    )
    artifact_job_lease: ArtifactJobLease | None = None
    if artifact_lifecycle is not None and worker_mode:
        artifact_job_id = (
            args.qfbv_artifact_job_id
            or os.environ.get("SYMCC_QFBV_ARTIFACT_JOB_ID", "")
            or (
                f"{socket.gethostname()}:{os.getpid()}:"
                f"{uuid.uuid4().hex}"
            )
        )
        artifact_job_lease = artifact_lifecycle.start_job(
            artifact_job_id,
            f"{socket.gethostname()}:{os.getpid()}",
            lease_seconds=artifact_job_lease_seconds,
        )
    context_max_objects = (
        args.qfbv_context_max_objects
        if args.qfbv_context_max_objects is not None
        else _environment_integer("SYMCC_QFBV_CONTEXT_MAX_OBJECTS", 1_000_000)
    )
    context_max_active = (
        args.qfbv_context_max_active
        if args.qfbv_context_max_active is not None
        else _environment_integer("SYMCC_QFBV_CONTEXT_MAX_ACTIVE", 64)
    )
    context_lease_seconds = (
        args.qfbv_context_lease_seconds
        if args.qfbv_context_lease_seconds is not None
        else _environment_float("SYMCC_QFBV_CONTEXT_LEASE_SECONDS", 30.0)
    )
    if not 1 <= context_max_objects <= 10_000_000:
        raise ValueError("--qfbv-context-max-objects must be in [1, 10000000]")
    if not 1 <= context_max_active <= 4096:
        raise ValueError("--qfbv-context-max-active must be in [1, 4096]")
    if not 0.1 <= context_lease_seconds <= 3600.0:
        raise ValueError("--qfbv-context-lease-seconds must be in [0.1, 3600]")
    context_store_raw = (
        str(args.qfbv_context_store)
        if args.qfbv_context_store is not None
        else os.environ.get("SYMCC_QFBV_CONTEXT_STORE", "")
    )
    shared_context_store = (
        CrossWorkerContextStore(
            context_store_raw,
            max_contexts=context_max_objects,
            max_active_materializations=context_max_active,
            lifecycle=artifact_lifecycle,
            lifecycle_lease=artifact_job_lease,
        )
        if context_store_raw
        else None
    )
    proof_max_objects = (
        args.qfbv_proof_max_objects
        if args.qfbv_proof_max_objects is not None
        else _environment_integer("SYMCC_QFBV_PROOF_MAX_OBJECTS", 1_000_000)
    )
    proof_max_bytes = (
        args.qfbv_proof_max_bytes
        if args.qfbv_proof_max_bytes is not None
        else _environment_integer("SYMCC_QFBV_PROOF_MAX_BYTES", MAX_PROOF_BYTES)
    )
    if not 1 <= proof_max_objects <= 10_000_000:
        raise ValueError("--qfbv-proof-max-objects must be in [1, 10000000]")
    if not 1024 <= proof_max_bytes <= MAX_PROOF_BYTES:
        raise ValueError(
            f"--qfbv-proof-max-bytes must be in [1024, {MAX_PROOF_BYTES}]"
        )
    proof_configured = any(
        isinstance(spec.get("unsat_proof"), dict)
        for spec in portfolio_specs
    )
    proof_store_raw = (
        str(args.qfbv_proof_store)
        if args.qfbv_proof_store is not None
        else os.environ.get("SYMCC_QFBV_PROOF_STORE", "")
    )
    if proof_configured and not proof_store_raw:
        proof_store_raw = str(Path(args.store) / "qfbv-unsat-proofs")
    proof_store = (
        QfbvProofStore(
            proof_store_raw,
            max_objects=proof_max_objects,
            max_proof_bytes=proof_max_bytes,
            lifecycle=artifact_lifecycle,
            lifecycle_lease=artifact_job_lease,
        )
        if proof_store_raw
        else None
    )
    lemma_configured = any(
        isinstance(spec.get("learned_lemmas"), dict)
        for spec in portfolio_specs
    )
    lemma_max_records = (
        args.qfbv_lemma_max_records
        if args.qfbv_lemma_max_records is not None
        else _environment_integer("SYMCC_QFBV_LEMMA_MAX_RECORDS", 1_000_000)
    )
    lemma_max_bytes = (
        args.qfbv_lemma_max_bytes
        if args.qfbv_lemma_max_bytes is not None
        else _environment_integer(
            "SYMCC_QFBV_LEMMA_MAX_BYTES", 256 * 1024 * 1024
        )
    )
    if not 1 <= lemma_max_records <= 10_000_000:
        raise ValueError("--qfbv-lemma-max-records must be in [1, 10000000]")
    if not MAX_RECORD_BYTES <= lemma_max_bytes <= 1 << 40:
        raise ValueError(
            f"--qfbv-lemma-max-bytes must be in [{MAX_RECORD_BYTES}, {1 << 40}]"
        )
    lemma_store_raw = (
        str(args.qfbv_lemma_store)
        if args.qfbv_lemma_store is not None
        else os.environ.get("SYMCC_QFBV_LEMMA_STORE", "")
    )
    if lemma_configured and not lemma_store_raw:
        lemma_store_raw = str(Path(args.store) / "qfbv-verified-lemmas")
    if lemma_configured and (shared_context_store is None or proof_store is None):
        raise ValueError(
            "learned lemma exchange requires QF_BV context and proof stores"
        )
    lemma_store = (
        QfbvLemmaStore(
            lemma_store_raw,
            max_records=lemma_max_records,
            max_bytes=lemma_max_bytes,
            lifecycle=artifact_lifecycle,
            lifecycle_lease=artifact_job_lease,
        )
        if lemma_store_raw
        else None
    )
    artifact_gc_result: ArtifactCollection | None = None
    artifact_gc_inventory: dict[str, dict[str, int | bool]] = {}

    def artifact_gc_payload(result: ArtifactCollection) -> dict[str, object]:
        return {
            "deleted": [
                {"kind": item.kind, "digest": item.digest}
                for item in result.deleted
            ],
            "deleted_objects": len(result.deleted),
            "deleted_bytes": result.deleted_bytes,
            "examined": result.examined,
            "protected": result.protected,
            "expired_jobs": result.expired_jobs,
            "stop_reason": result.stop_reason,
        }

    def delete_artifact(kind: str, digest: str, size: int) -> int:
        if kind == "context" and shared_context_store is not None:
            return shared_context_store.delete_lifecycle_artifact(
                kind, digest, size
            )
        if kind in {"proof", "receipt"} and proof_store is not None:
            return proof_store.delete_lifecycle_artifact(kind, digest, size)
        if kind == "lemma" and lemma_store is not None:
            return lemma_store.delete_lifecycle_artifact(kind, digest, size)
        raise RuntimeError(f"artifact GC store for {kind!r} is unavailable")

    if args.qfbv_artifact_gc_on_start or args.qfbv_artifact_gc_only:
        assert artifact_lifecycle is not None
        context_count = (
            shared_context_store.stats()["contexts"]
            if shared_context_store is not None
            else 0
        )
        proof_stats = proof_store.stats() if proof_store is not None else {}
        proof_count = int(proof_stats.get("proofs", 0)) + int(
            proof_stats.get("receipts", 0)
        )
        lemma_count = (
            lemma_store.stats()["records"] if lemma_store is not None else 0
        )
        indexed_total = context_count + proof_count + lemma_count
        if indexed_total > artifact_gc_scan_max_objects:
            raise RuntimeError(
                "artifact GC index synchronization budget is insufficient: "
                f"{indexed_total} > {artifact_gc_scan_max_objects}"
            )
        if shared_context_store is not None:
            artifact_gc_inventory["context"] = (
                shared_context_store.synchronize_lifecycle(
                    max_entries=artifact_gc_scan_max_objects
                )
            )
        if proof_store is not None:
            artifact_gc_inventory["proof"] = proof_store.synchronize_lifecycle(
                max_entries=artifact_gc_scan_max_objects
            )
        if lemma_store is not None:
            artifact_gc_inventory["lemma"] = lemma_store.synchronize_lifecycle(
                max_entries=artifact_gc_scan_max_objects
            )
        if not all(
            bool(result["complete"])
            for result in artifact_gc_inventory.values()
        ):
            raise RuntimeError("artifact GC index synchronization is incomplete")
        artifact_gc_result = artifact_lifecycle.collect(
            delete_artifact,
            grace_seconds=artifact_gc_grace_seconds,
            max_objects=artifact_gc_max_objects,
            max_bytes=artifact_gc_max_bytes,
            time_budget_ms=artifact_gc_time_ms,
        )
    if args.qfbv_artifact_gc_only:
        assert artifact_lifecycle is not None
        assert artifact_gc_result is not None
        print(
            json.dumps(
                {
                    "qfbv_artifact_gc": artifact_gc_payload(
                        artifact_gc_result
                    ),
                    "qfbv_artifact_gc_inventory": artifact_gc_inventory,
                    "qfbv_artifact_lifecycle": artifact_lifecycle.stats(),
                },
                sort_keys=True,
            )
        )
        return 0

    def validate_schedule_constraints() -> int:
        if not args.schedule_constraints:
            return 0
        return store.validate_schedule_constraints_file(
            args.schedule_constraints,
            output_path=args.schedule_validation_out,
            max_artifacts=max(args.schedule_validation_max_artifacts, 0),
        )

    if args.schedule_validation_only:
        written = validate_schedule_constraints()
        print(
            json.dumps(
                {
                    "schedule_validations": written,
                    "store": store.stats(),
                },
                sort_keys=True,
            )
        )
        return 0
    if args.artifact_audit_only:
        audit = store.audit_artifacts(
            max_entries=args.artifact_audit_max_entries,
        )
        print(json.dumps(audit, sort_keys=True))
        return 0 if bool(audit["scan"]["complete"]) else 2
    if args.stats:
        validate_schedule_constraints()
        stats: dict[str, object] = store.stats()
        if shared_context_store is not None:
            stats = {
                "store": stats,
                "qfbv_context_store": shared_context_store.stats(),
            }
        if proof_store is not None:
            if "store" not in stats:
                stats = {"store": stats}
            stats["qfbv_proof_store"] = proof_store.stats()
        if lemma_store is not None:
            if "store" not in stats:
                stats = {"store": stats}
            stats["qfbv_lemma_store"] = lemma_store.stats()
        if artifact_lifecycle is not None:
            if "store" not in stats:
                stats = {"store": stats}
            stats["qfbv_artifact_lifecycle"] = artifact_lifecycle.stats()
        if artifact_gc_result is not None:
            if "store" not in stats:
                stats = {"store": stats}
            stats["qfbv_artifact_gc"] = artifact_gc_payload(
                artifact_gc_result
            )
            stats["qfbv_artifact_gc_inventory"] = artifact_gc_inventory
        print(json.dumps(stats, sort_keys=True))
        return 0
    solver_command = (
        []
        if portfolio_specs
        else (shlex.split(args.solver) if args.solver else _default_solver())
    )
    jobs = max(1, min(256, args.jobs))
    stop = threading.Event()

    def request_stop(_signum: int, _frame: object) -> None:
        stop.set()

    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)

    def worker(slot: int, one_pass: bool) -> dict[str, int]:
        local_store = QueryStore(args.store)
        owner = f"{socket.gethostname()}:{os.getpid()}:{slot}"
        counts = {"sat": 0, "unsat": 0, "unknown": 0, "error": 0, "stale": 0}
        stack = ExitStack()

        def persistent_backend(
            command: list[str],
            backend_index: int,
        ) -> PersistentSubprocessSolver:
            environment: dict[str, str] = {}
            if "SYMCC_SELECTIVE_QUERY_POLICY_STATE" not in os.environ:
                policy_dir = Path(args.store) / "policies"
                policy_dir.mkdir(parents=True, exist_ok=True)
                environment["SYMCC_SELECTIVE_QUERY_POLICY_STATE"] = str(
                    policy_dir
                    / f"selective-worker-{slot}-backend-{backend_index}.state"
                )
            return PersistentSubprocessSolver(command, environment=environment)

        if portfolio_specs:
            portfolio_backends = []
            for backend_index, spec in enumerate(portfolio_specs):
                command = spec["command"]
                assert isinstance(command, list)
                kind = str(spec.get("kind", "symcc-json"))
                if kind == "smtlib-qfbv":
                    capabilities = spec.get("capabilities")
                    assert isinstance(capabilities, dict)
                    proof_verifier = None
                    proof_spec = spec.get("unsat_proof")
                    if isinstance(proof_spec, dict):
                        if proof_store is None:
                            raise RuntimeError(
                                "QF_BV proof verifier requires a proof store"
                            )
                        proof_verifier = QfbvProofVerifier(
                            proof_store,
                            generator_command=proof_spec["generator_command"],
                            checker_command=proof_spec["checker_command"],
                            signature_root=str(proof_spec["signature_root"]),
                            generator_trusted_files=proof_spec[
                                "generator_trusted_files"
                            ],
                            checker_trusted_files=proof_spec[
                                "checker_trusted_files"
                            ],
                            timeout_ms=int(proof_spec["timeout_ms"]),
                        )
                        local_store.register_qfbv_proof_verifier(proof_verifier)
                    lemma_exchange = None
                    lemma_spec = spec.get("learned_lemmas")
                    if isinstance(lemma_spec, dict):
                        if (
                            lemma_store is None
                            or shared_context_store is None
                            or proof_verifier is None
                        ):
                            raise RuntimeError(
                                "learned lemma exchange stores are unavailable"
                            )
                        lemma_exchange = QfbvLemmaExchange(
                            lemma_store,
                            shared_context_store,
                            proof_verifier,
                            timeout_ms=int(lemma_spec["timeout_ms"]),
                        )
                        local_store.register_qfbv_lemma_exchange(lemma_exchange)
                    if bool(spec.get("persistent", False)):
                        backend = stack.enter_context(
                            PersistentSmtLibQfbvSolver(
                                local_store,
                                command,
                                name=str(spec["name"]),
                                capabilities=capabilities,
                                prefix_cache_entries=int(spec.get("prefix_cache", 4)),
                                shared_context_store=shared_context_store,
                                context_owner=(
                                    f"{owner}:backend-{backend_index}:"
                                    f"{spec['name']}"
                                ),
                                materialization_lease_seconds=(
                                    context_lease_seconds
                                ),
                                materialization_max_active=(
                                    context_max_active
                                ),
                                proof_verifier=proof_verifier,
                                lemma_exchange=lemma_exchange,
                                learned_literal_type=str(
                                    lemma_spec.get("type", "preprocess")
                                )
                                if isinstance(lemma_spec, dict)
                                else "preprocess",
                                max_learned_lemmas=int(
                                    lemma_spec.get("max_per_query", 8)
                                )
                                if isinstance(lemma_spec, dict)
                                else 8,
                                lemma_timeout_ms=int(
                                    lemma_spec.get("timeout_ms", 30_000)
                                )
                                if isinstance(lemma_spec, dict)
                                else 30_000,
                            )
                        )
                    else:
                        backend = SmtLibQfbvSolver(
                            local_store,
                            command,
                            name=str(spec["name"]),
                            capabilities=capabilities,
                            proof_verifier=proof_verifier,
                        )
                elif bool(spec.get("persistent", True)):
                    backend = stack.enter_context(
                        persistent_backend(command, backend_index)
                    )
                else:
                    backend = SubprocessSolver(command)
                portfolio_backends.append((str(spec["name"]), backend))
            backend = PortfolioSolver(
                portfolio_backends,
                parallelism=args.portfolio_parallelism or None,
                cancel_grace_ms=args.portfolio_cancel_grace_ms,
            )
        else:
            backend = stack.enter_context(persistent_backend(solver_command, 0))
        with stack:
            while not stop.is_set():
                status = solve_one(
                    local_store,
                    owner,
                    backend,
                    lease_seconds=max(args.lease_seconds, 0.1),
                    max_attempts=max(args.max_attempts, 1),
                    traversal=args.traversal,
                    shard_index=slot,
                    shard_count=jobs,
                )
                if status is None:
                    if one_pass:
                        break
                    stop.wait(max(args.poll, 0.01))
                    continue
                counts[status] = counts.get(status, 0) + 1
        return counts

    if args.spool:
        ingest_spool(store, args.spool)
    validate_schedule_constraints()
    artifact_heartbeat = (
        ArtifactLeaseHeartbeat(
            artifact_lifecycle,
            artifact_job_lease,
            lease_seconds=artifact_job_lease_seconds,
        )
        if artifact_lifecycle is not None and artifact_job_lease is not None
        else None
    )
    if args.once:
        try:
            with ThreadPoolExecutor(max_workers=jobs) as executor:
                results = list(
                    executor.map(lambda slot: worker(slot, True), range(jobs))
                )
        finally:
            if artifact_heartbeat is not None:
                artifact_heartbeat.close()
        if args.spool:
            ingest_spool(store, args.spool)
        validate_schedule_constraints()
        aggregate: dict[str, int] = {}
        for result in results:
            for key, value in result.items():
                aggregate[key] = aggregate.get(key, 0) + value
        summary: dict[str, object] = {
            "worker": aggregate,
            "store": store.stats(),
        }
        if shared_context_store is not None:
            summary["qfbv_context_store"] = shared_context_store.stats()
        if proof_store is not None:
            summary["qfbv_proof_store"] = proof_store.stats()
        if lemma_store is not None:
            summary["qfbv_lemma_store"] = lemma_store.stats()
        if artifact_lifecycle is not None:
            summary["qfbv_artifact_lifecycle"] = artifact_lifecycle.stats()
        if artifact_gc_result is not None:
            summary["qfbv_artifact_gc"] = artifact_gc_payload(
                artifact_gc_result
            )
            summary["qfbv_artifact_gc_inventory"] = artifact_gc_inventory
        print(json.dumps(summary, sort_keys=True))
        return 0

    try:
        with ThreadPoolExecutor(max_workers=jobs) as executor:
            futures = [executor.submit(worker, slot, False) for slot in range(jobs)]
            try:
                while not stop.wait(max(args.poll, 0.01)):
                    if artifact_heartbeat is not None:
                        artifact_heartbeat.check()
                    if args.spool:
                        ingest_spool(store, args.spool)
                    validate_schedule_constraints()
            finally:
                stop.set()
                for future in futures:
                    future.result()
    finally:
        if artifact_heartbeat is not None:
            artifact_heartbeat.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
