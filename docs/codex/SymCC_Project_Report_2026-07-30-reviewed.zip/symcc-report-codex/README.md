# Codex 文档交付区

本目录只保存 Codex 生成和审核的项目汇报材料，用于避免与
`docs/cc/` 以及 `docs/` 根目录中的并发编辑产生冲突。后续 Codex 文档工作仅修改
本目录；仓库原有文档作为外部参考，不在这里复制维护。

## 主要交付物

| 内容 | 文件 |
| --- | --- |
| 完整项目报告 | [`Project_Report_2026-07.md`](Project_Report_2026-07.md) |
| 在线阅读版本 | [`Project_Report_2026-07.html`](Project_Report_2026-07.html) |
| 28 页汇报演示稿 | [`Project_Progress_Presentation_2026-07-30.pptx`](Project_Progress_Presentation_2026-07-30.pptx) |
| 演示稿文字源 | [`Project_Progress_Presentation_2026-07-30.md`](Project_Progress_Presentation_2026-07-30.md) |
| 当前实现评估 | [`Current_Implementation_Evaluation_2026-07-30.md`](Current_Implementation_Evaluation_2026-07-30.md) |
| 技术全景 | [`Current_Technology_Compendium.md`](Current_Technology_Compendium.md) |
| 架构与实验问答 | [`Architecture_QA3.md`](Architecture_QA3.md) |
| 新实现技术档案 | [`New_Implementation_Archive.md`](New_Implementation_Archive.md) |
| 开发历史追踪 | [`Development_History_Traceability.md`](Development_History_Traceability.md) |
| 迁移后审阅记录 | [`Document_Review_2026-07-30.md`](Document_Review_2026-07-30.md) |
| 审核后完整包 | [`SymCC_Project_Report_2026-07-30-reviewed.zip`](SymCC_Project_Report_2026-07-30-reviewed.zip) |
| 迁移前封存包 | [`SymCC_Project_Report_2026-07-30.zip`](SymCC_Project_Report_2026-07-30.zip) |
| 浏览入口 | [`index.html`](index.html) |

## 配套材料

- `diagrams/report/`：项目报告图集及 Graphviz 源文件；
- `diagrams/qa3/`：架构、求解策略和实验流程图集；
- `diagrams/technology_compendium/`：技术栈总览；
- `evidence/current-eval-2026-07-30/`：当前配置消融和统计结果；
- `evidence/lava_m_current_2026_07_30/`：LAVA-M 当前实测数据；
- `evidence/img_*.png`：执行流和调试证据截图；
- [`verify_delivery.py`](verify_delivery.py)：本地链接、图形、PPTX 与关键计数校验；
- [`report.css`](report.css)：HTML 报告排版样式；
- [`PACKAGE_MANIFEST.sha256`](PACKAGE_MANIFEST.sha256)：审核后 ZIP 内文件内容清单；
- [`SHA256SUMS.txt`](SHA256SUMS.txt)：顶层核心交付物校验值。

`SymCC_Project_Report_2026-07-30.zip` 保留迁移前封存快照。目录内可读文档已针对
`docs/codex/` 的层级修正仓库相对链接，因此其哈希与 ZIP 内原始副本可能不同。
本次审核后的当前材料封装在 `SymCC_Project_Report_2026-07-30-reviewed.zip`，两者用途
不同，不能用旧 ZIP 覆盖当前可读文件。

## 外部依赖

文档中指向 `../Configuration.txt`、`../sota_hybrid_execution_2026.md` 等链接时，
引用的是仓库原有文档；指向 `../../benchmark/` 或 `../../pafl.pdf` 时，引用的是
仓库级实验脚本或论文材料。
